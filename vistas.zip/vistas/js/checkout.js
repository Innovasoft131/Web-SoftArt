var model = document.querySelector(".model");

function fadeIn () {
  model.className += " fadeIn";
}


