<div class="model mostrar">
    <div class="room mostrar">
        <div class="text-cover">
            <h1>Innovasoft</h1>
            <!-- p class="price"> 120.00 <span>USD</span> / Night</p -->
            <hr>
            <!-- p>Entire Home for 1 guest</p-->
            <p><?php echo date('d-m-y'); ?></p>
        </div>
    </div>
    <div class="payment mostrar">
        <div class="receipt-box">
            <h3>Resumen de recibo</h3>
            <table class="table">
                <tr>
                    <td>Diseño 1</td>
                    <td>$240.00</td>
                </tr>
                <tr>
                    <td>Diseño 2</td>
                    <td>$500.00</td>
                </tr>
                <tr>
                    <td>Diseño 3</td>
                    <td>$540.00</td>
                </tr>
                <tr>
                    <td>Diseño 4</td>
                    <td>$10.00</td>
                </tr>
                <tfoot>
                    <tr>
                        <td><h4>Total</h4></td>
                        <td><h4>$1800.00</h4></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="payment-info">
            <h3>Método de pago</h3>
            <form>
                <label>Seleccione método de pago</label>
                <select class="metodoPago">
                    <option value="paypal">paypal</option>
                    <option value="Visa">Visa</option>
                </select>
                <br><br>
                <input class="btn-checkout" type="submit" value="Realizar Pago">
            </form>
        </div>
    </div>
</div>