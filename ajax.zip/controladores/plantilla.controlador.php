<?php

class ControladorPlantilla{

    // Llamamos a los modelos
    public function plantilla(){
        include 'vistas/plantilla.php';
    }
}